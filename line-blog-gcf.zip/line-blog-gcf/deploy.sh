#!/bin/bash

# Google Cloud Functionsにデプロイ
echo 'Deploying to Google Cloud Functions...'

gcloud functions deploy lineWebhook \
  --runtime nodejs20 \
  --trigger-http \
  --allow-unauthenticated \
  --env-vars-file .env.yaml \
  --region asia-northeast1 \
  --project line-blog-generator

echo 'Deployment complete!'
