const express = require('express');
const crypto = require('crypto');
const { Anthropic } = require('@anthropic-ai/sdk');
const fs = require('fs').promises;
const path = require('path');
const axios = require('axios');

const app = express();
app.use(express.json());

// 環境変数
const LINE_CHANNEL_SECRET = process.env.LINE_CHANNEL_SECRET || 'your-line-channel-secret';
const LINE_CHANNEL_ACCESS_TOKEN = process.env.LINE_CHANNEL_ACCESS_TOKEN || 'your-line-access-token';
const CLAUDE_API_KEY = process.env.CLAUDE_API_KEY || 'your-claude-api-key';

// Claude初期化
const anthropic = new Anthropic({
  apiKey: CLAUDE_API_KEY.replace(/\s+/g, ''),
});

// ローカル保存フォルダ
const BLOG_DIR = path.join(__dirname, 'blogs');

// フォルダ作成
async function ensureBlogDir() {
  try {
    await fs.mkdir(BLOG_DIR, { recursive: true });
  } catch (error) {
    console.error('Error creating blog directory:', error);
  }
}

// LINE署名検証
function validateSignature(body, signature) {
  const channelSecret = LINE_CHANNEL_SECRET;
  const bodyString = JSON.stringify(body);
  const hash = crypto.createHmac('sha256', channelSecret).update(bodyString).digest('base64');
  return hash === signature;
}

// Webhook エンドポイント
app.post('/webhook', async (req, res) => {
  console.log('Webhook received');

  try {
    // 署名検証（デバッグ用に一時的にスキップ）
    // const signature = req.get('x-line-signature');
    // if (!validateSignature(req.body, signature)) {
    //   return res.status(401).send('Unauthorized');
    // }

    const events = req.body.events || [];
    
    for (const event of events) {
      if (event.type === 'message' && event.message.type === 'text') {
        const text = event.message.text;
        const replyToken = event.replyToken;
        console.log('Message:', text);
        
        try {
          // ブログ生成
          const blogContent = await generateBlog(text);
          console.log('Blog generated successfully');
          
          // ローカルに保存
          const filePath = await saveToLocal(blogContent, text);
          console.log('Saved to local:', filePath);
          
          // LINE に成功メッセージを送信
          const successMessage = `🎉 ブログ記事の生成が完了しました！

📝 テーマ: 「${text}」
📄 ファイル名: ${path.basename(filePath)}
🌐 ブログサイト: http://localhost:3000

新しい記事がブログサイトに表示されています。ページを更新してご確認ください！`;
          
          await replyToLine(replyToken, successMessage);
          
        } catch (error) {
          console.error('Blog generation error:', error);
          // LINE にエラーメッセージを送信
          await replyToLine(replyToken, `❌ ブログ作成中にエラーが発生しました。
          
詳細: ${error.message}
ローカルファイルの保存は継続されています。`);
        }
      }
    }
    
    res.status(200).send('OK');
  } catch (error) {
    console.error('Full error details:', {
      message: error.message,
      stack: error.stack,
      name: error.name
    });
    res.status(200).send('OK');
  }
});

async function generateBlog(topic) {
  try {
    console.log('Starting blog generation for topic:', topic);
    console.log('CLAUDE_API_KEY exists:', !!CLAUDE_API_KEY);
    
    const prompt = `「${topic}」についてのブログ記事を日本語で作成してください。
    
    以下の構成で書いてください：
    1. キャッチーなタイトル
    2. 導入文
    3. 本文（3つのセクション）
    4. まとめ
    
    読みやすく、SEOも意識した文章でお願いします。`;
    
    console.log('Calling Claude API...');
    const message = await anthropic.messages.create({
      model: 'claude-3-5-sonnet-20241022',
      max_tokens: 2000,
      messages: [{ role: 'user', content: prompt }]
    });
    
    const text = message.content[0].text;
    console.log('Claude response received, length:', text.length);
    return text;
    
  } catch (error) {
    console.error('Claude API error details:', {
      message: error.message,
      stack: error.stack,
      name: error.name,
      status: error.status,
      statusText: error.statusText
    });
    return `# ${topic}について

エラーが発生しました: ${error.message}`;
  }
}

async function saveToLocal(content, topic) {
  try {
    await ensureBlogDir();
    
    const fileName = `blog_${topic}_${Date.now()}.md`;
    const filePath = path.join(BLOG_DIR, fileName);
    
    await fs.writeFile(filePath, content, 'utf8');
    
    console.log('File saved locally:', fileName);
    console.log('Location:', filePath);
    
    return filePath;
    
  } catch (error) {
    console.error('Local save error:', error);
    throw error;
  }
}

// LINE返信機能
async function replyToLine(replyToken, message) {
  try {
    console.log('=== LINE Reply Debug Info ===');
    console.log('Reply Token:', replyToken);
    console.log('Token length:', LINE_CHANNEL_ACCESS_TOKEN.length);
    console.log('Token prefix:', LINE_CHANNEL_ACCESS_TOKEN.substring(0, 20) + '...');
    console.log('Token contains newline:', LINE_CHANNEL_ACCESS_TOKEN.includes('\n'));
    console.log('Message length:', message.length);
    
    const cleanToken = LINE_CHANNEL_ACCESS_TOKEN.replace(/\s+/g, '');
    
    const requestData = {
      replyToken: replyToken,
      messages: [{
        type: 'text',
        text: message
      }]
    };
    
    console.log('Request data:', JSON.stringify(requestData, null, 2));
    
    const response = await axios.post('https://api.line.me/v2/bot/message/reply', requestData, {
      headers: {
        'Authorization': `Bearer ${cleanToken}`,
        'Content-Type': 'application/json'
      }
    });
    
    console.log('Reply sent successfully');
    console.log('Response status:', response.status);
  } catch (error) {
    console.error('=== LINE Reply Error ===');
    console.error('Error details:', error.response?.data || error.message);
    console.error('Status:', error.response?.status);
    console.error('Headers:', error.response?.headers);
  }
}

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});