// テストスクリプト
const axios = require('axios');

async function test() {
  try {
    const response = await axios.post('http://localhost:8080', {
      events: [{
        type: 'message',
        message: {
          type: 'text',
          text: 'AIについて'
        }
      }]
    });
    console.log('Success:', response.data);
  } catch (error) {
    console.error('Error:', error.message);
  }
}

test();
