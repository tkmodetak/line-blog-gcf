#!/bin/bash
echo 'Starting server with environment variables...'
export LINE_CHANNEL_SECRET=$(grep LINE_CHANNEL_SECRET .env.yaml | cut -d"'" -f2)
export GEMINI_API_KEY=$(grep GEMINI_API_KEY .env.yaml | cut -d"'" -f2)
echo "GEMINI_API_KEY is set to: ${GEMINI_API_KEY:0:10}..."
npm start
