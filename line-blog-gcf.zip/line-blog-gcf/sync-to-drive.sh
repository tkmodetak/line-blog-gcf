#!/bin/bash
# Google Drive自動同期スクリプト

BLOG_DIR="$HOME/Desktop/line-blog-gcf/blogs"
DRIVE_DIR="$HOME/Google Drive/My Drive/LINE-Blogs"

echo "📁 Syncing blogs to Google Drive..."

# Google Driveフォルダが存在しない場合は作成
mkdir -p "$DRIVE_DIR"

# ブログファイルをコピー
cp -r "$BLOG_DIR"/* "$DRIVE_DIR"/

echo "✅ Sync complete!"
echo "📍 Files copied to: $DRIVE_DIR"
