const crypto = require('crypto');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const { google } = require('googleapis');
const fs = require('fs');
const path = require('path');

// 環境変数
const LINE_CHANNEL_SECRET = process.env.LINE_CHANNEL_SECRET;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

// Gemini初期化
const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);

// Google Drive認証
const auth = new google.auth.GoogleAuth({
  keyFile: path.join(__dirname, 'service-account.json'),
  scopes: ['https://www.googleapis.com/auth/drive.file']
});

const drive = google.drive({ version: 'v3', auth });

exports.lineWebhook = async (req, res) => {
  console.log('Webhook received');

  try {
    const events = req.body.events || [];
    
    for (const event of events) {
      if (event.type === 'message' && event.message.type === 'text') {
        const text = event.message.text;
        console.log('Message:', text);
        
        // ブログ生成
        const blogContent = await generateBlog(text);
        console.log('Blog generated successfully');
        
        // Google Driveに保存
        const fileId = await saveToDrive(blogContent, text);
        console.log('Saved to Google Drive:', fileId);
      }
    }
    
    res.status(200).send('OK');
  } catch (error) {
    console.error('Error:', error);
    res.status(200).send('OK');
  }
};

async function generateBlog(topic) {
  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-pro' });
    
    const prompt = `「${topic}」についてのブログ記事を日本語で作成してください。
    
    以下の構成で書いてください：
    1. キャッチーなタイトル
    2. 導入文
    3. 本文（3つのセクション）
    4. まとめ
    
    読みやすく、SEOも意識した文章でお願いします。`;
    
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    return text;
    
  } catch (error) {
    console.error('Gemini API error:', error);
    return `# ${topic}について

エラーが発生しました。`;
  }
}

async function saveToDrive(content, topic) {
  try {
    const fileName = `blog_${topic}_${Date.now()}.md`;
    
    const fileMetadata = {
      name: fileName,
      mimeType: 'application/vnd.google-apps.document'
    };
    
    const media = {
      mimeType: 'text/markdown',
      body: content
    };
    
    const response = await drive.files.create({
      requestBody: fileMetadata,
      media: media,
      fields: 'id, name, webViewLink'
    });
    
    console.log('File created:', response.data.name);
    console.log('View link:', response.data.webViewLink);
    
    return response.data.id;
    
  } catch (error) {
    console.error('Google Drive error:', error);
    throw error;
  }
}
