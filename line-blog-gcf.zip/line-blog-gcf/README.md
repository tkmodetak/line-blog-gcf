# LINE Blog Generator - Google Cloud Functions

## セットアップ手順

### 1. Google Cloud準備
1. [Google Cloud Console](https://console.cloud.google.com/)にアクセス
2. 新規プロジェクト作成: `line-blog-generator`
3. Cloud Functions APIを有効化
4. Google Drive APIを有効化

### 2. Google Cloud CLIインストール
```bash
# Homebrewを使用
brew install google-cloud-sdk

# 認証
gcloud auth login
gcloud config set project line-blog-generator
```

### 3. 環境変数設定
`.env.yaml`ファイルを編集:
- LINE_CHANNEL_SECRET: LINE Developersから取得
- CLAUDE_API_KEY: Anthropicから取得

### 4. ローカルテスト
```bash
# 依存関係インストール
npm install

# ローカル実行
npm start

# 別ターミナルでテスト
npm test
```

### 5. デプロイ
```bash
./deploy.sh
```

### 6. LINE Webhook設定
デプロイ後に表示されるURLをLINE Developersに設定:
```
https://asia-northeast1-line-blog-generator.cloudfunctions.net/lineWebhook
```

## ファイル構成
- `index.js` - メイン処理
- `package.json` - 依存関係
- `.env.yaml` - 環境変数
- `deploy.sh` - デプロイスクリプト

## トラブルシューティング
- ログ確認: `gcloud functions logs read lineWebhook`
- エラー時は`index.js`のconsole.logを確認
